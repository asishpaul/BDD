package com.cap.dao;

public interface ILoginDao {

	public boolean validateUser(String username, String password);

}
