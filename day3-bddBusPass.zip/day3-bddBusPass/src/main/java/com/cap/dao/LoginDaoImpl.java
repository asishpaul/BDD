package com.cap.dao;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public boolean validateUser(String username, String password) {
		
		return true;
	}

}
