package com.cap.service;

import com.cap.dao.ILoginDao;

public class LoginServiceImpl implements ILoginService {
	
	private ILoginDao loginDao;

	public LoginServiceImpl(ILoginDao loginDao) {
		
		this.loginDao = loginDao;
	}

	public void setLoginDao(ILoginDao loginDao) {
		this.loginDao = loginDao;
	}

	@Override
	public boolean validateUser(String username, String password) {
		
		return loginDao.validateUser(username, password);
	}
	
	
	
	

}
