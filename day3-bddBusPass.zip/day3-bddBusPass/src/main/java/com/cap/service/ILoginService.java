package com.cap.service;

public interface ILoginService {
	public boolean validateUser(String username, String password);


}
