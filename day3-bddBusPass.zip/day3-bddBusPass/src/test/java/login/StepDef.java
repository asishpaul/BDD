package login;





import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cap.dao.ILoginDao;
import com.cap.model.Login;
import com.cap.service.ILoginService;
import com.cap.service.LoginServiceImpl;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private Login login;
	private ILoginService loginService;
	
	@Mock
	private ILoginDao loginDao;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		loginService=new LoginServiceImpl(loginDao);
		
	}
	
	
	@Given("^User name$")
	public void user_name() throws Throwable {
	    login=new Login();
	    login.setUserName("antara");
	}

	@Given("^User password$")
	public void user_password() throws Throwable {
	   login.setUserPassword("ant123");
	}

	@When("^Valid details$")
	public void valid_details() throws Throwable {
	   login=new Login("antara","ant123");
	   //dummy
	   Mockito.when(loginDao.validateUser("antara","ant123")).thenReturn(true);
	   //actual logic
	   boolean status=loginService.validateUser("antara", "ant123");
	   
	   //Mockito verify
	   Mockito.verify(loginDao).validateUser("antara", "ant123");
	   assertTrue(status);
		
	}
	
	@Then("^login Successful$")
	public void login_Successful() throws Throwable {
	   System.out.println("login successful");
	}

	@When("^Invalid details$")
	public void invalid_details() throws Throwable {
		login=new Login("antara","ant123");
		   //dummy
		   Mockito.when(loginDao.validateUser("xyz","xyz123")).thenReturn(false);
		   //actual logic
		   boolean status=loginService.validateUser("xyz", "xyz123");
		   
		   //Mockito verify
		   Mockito.verify(loginDao).validateUser("xyz", "xyz123");
		   assertFalse(status);
		
	}

	@Then("^login failure$")
	public void login_failure() throws Throwable {
	    
	}


	


}
