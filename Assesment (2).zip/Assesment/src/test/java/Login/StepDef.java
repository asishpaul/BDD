package Login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private WebDriver webDriver;
	private WebElement element;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\drivers\\chromedriver.exe");
		webDriver=new ChromeDriver();
	}
	
	@Given("^Verify the login page heading and provide username and password$")
	public void verify_the_login_page_heading_and_provide_username_and_password() throws Throwable {
		webDriver.get("http://localhost:8086/Assessment/pages/login.html");
		 String innerText=webDriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		 Thread.sleep(1000);
		 webDriver.findElement(By.name("userName")).sendKeys("Capgemini");
		 webDriver.findElement(By.name("userPwd")).sendKeys("capg1234");
	}

	@When("^submit after validating username and password$")
	public void submit_after_validating_username_and_password() throws Throwable {
		element=webDriver.findElement(By.className("btn"));
		element.submit();
	}

	@Then("^open the bookingpage$")
	public void open_the_bookingpage() throws Throwable {
		 webDriver.navigate().to("http://localhost:8086/Assessment/pages/hotelbooking.html");
	}

	@Given("^Verify the login page heading and provide user name$")
	public void verify_the_login_page_heading_and_provide_user_name() throws Throwable {
		webDriver.get("http://localhost:8086/Assessment/pages/login.html");
		String innerText=webDriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		 Thread.sleep(1000);
		 webDriver.findElement(By.name("userName")).sendKeys("Capgemini");
	}

	@When("^password is not given$")
	public void password_is_not_given() throws Throwable {
	    
	}

	@Then("^throw error message 'please enter password'$")
	public void throw_error_message_please_enter_password() throws Throwable {
	   
	}

	@Given("^Verify the login page heading and provide password$")
	public void verify_the_login_page_heading_and_provide_password() throws Throwable {
	   
	}

	@When("^username is not given$")
	public void username_is_not_given() throws Throwable {
	  
	}

	@Then("^throw error message 'please enter username'$")
	public void throw_error_message_please_enter_username() throws Throwable {
	  
	}

	
}
